#include <stdio.h>

int main(void)
{
printf("My custom program was found and run!\n");
}
